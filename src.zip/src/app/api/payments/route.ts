import { payments } from "@/server/mockDb"
import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json(payments)
}

export async function POST(req: Request) {
  const body = await req.json()
  return NextResponse.json({ ok: true, received: body })
}
