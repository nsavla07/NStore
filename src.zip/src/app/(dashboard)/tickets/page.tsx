"use client"
import Card from "@/components/Card"
import DataTable from "@/components/DataTable"
import Modal from "@/components/Modal"
import ChatThread from "@/components/ChatThread"
import { RoleGuard, useAuth } from "@/lib/auth"
import { apiGet, apiPost } from "@/lib/api"
import { useEffect, useState } from "react"
import type { Ticket as TicketType } from "@/server/mockDb"

export default function TicketsPage() {
  const [data, setData] = useState<TicketType[]>([])
  const [open, setOpen] = useState(false)
  const [title, setTitle] = useState("")
  const [priority, setPriority] = useState<TicketType["priority"]>("low")
  const { role } = useAuth()
  const [selected, setSelected] = useState<TicketType | null>(null)

  useEffect(() => { apiGet<TicketType[]>("/api/tickets").then(setData) }, [])

  function submit() {
    apiPost("/api/tickets", { title, priority, assigneeRole: role ?? null }).then(() => setOpen(false))
  }

  function assign(roleName: TicketType["assigneeRole"]) {
    if (!selected) return
    setData(prev => prev.map(t => t.id === selected.id ? { ...t, assigneeRole: roleName } : t))
    setSelected(s => s ? { ...s, assigneeRole: roleName } : s)
  }

  function escalate() {
    assign("manager")
    if (!selected) return
    setData(prev => prev.map(t => t.id === selected.id ? { ...t, priority: "high" } : t))
    setSelected(s => s ? { ...s, priority: "high" } : s)
  }

  function sendMessage(text: string) {
    if (!selected || !role) return
    setData(prev => prev.map(t => t.id === selected.id ? { ...t, comments: [...t.comments, { by: role, text, at: new Date().toISOString() }] } : t))
    setSelected(s => s ? { ...s, comments: [...s.comments, { by: role, text, at: new Date().toISOString() }] } : s)
  }

  return (
    <RoleGuard allowed={["agent", "manager", "admin"]}>
      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Create">
          <button className="rounded bg-brand-500 px-3 py-2 text-sm text-white" onClick={() => setOpen(true)}>New ticket</button>
        </Card>
        <Card title="Assignment">
          <div className="text-sm text-gray-600">Role: {role ?? "none"}</div>
        </Card>
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <DataTable<TicketType>
          columns={[
            { key: "id", header: "Ticket" },
            { key: "title", header: "Title" },
            { key: "status", header: "Status" },
            { key: "priority", header: "Priority" },
            { key: "assigneeRole", header: "Assignee" }
          ]}
          data={data}
          onRowClick={(row) => setSelected(row)}
        />
        <Card title="Discussion">
          {selected ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <select value={selected.assigneeRole ?? ""} onChange={e => assign((e.target.value || null) as TicketType["assigneeRole"])} className="rounded border px-2 py-1">
                  <option value="">Unassigned</option>
                  <option value="agent">Agent</option>
                  <option value="manager">Manager</option>
                  <option value="admin">Admin</option>
                </select>
                <button className="rounded border px-2 py-1 text-sm" onClick={escalate}>Escalate</button>
              </div>
              <ChatThread messages={selected.comments} onSend={sendMessage} />
            </div>
          ) : <div className="text-sm text-gray-600">Select a ticket</div>}
        </Card>
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="New ticket">
        <div className="space-y-3">
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" className="w-full rounded border px-3 py-2" />
          <select value={priority} onChange={e => setPriority(e.target.value as TicketType["priority"])} className="w-full rounded border px-3 py-2">
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
          <div className="flex justify-end gap-2">
            <button className="rounded px-3 py-2" onClick={() => setOpen(false)}>Cancel</button>
            <button className="rounded bg-gray-800 px-3 py-2 text-white" onClick={submit}>Submit</button>
          </div>
        </div>
      </Modal>
    </RoleGuard>
  )
}
