"use client"
import Card from "@/components/Card"
import DataTable from "@/components/DataTable"
import { Timeline } from "@/components/Timeline"
import SearchFilterBar from "@/components/SearchFilterBar"
import Badge from "@/components/Badge"
import { RoleGuard } from "@/lib/auth"
import { apiGet } from "@/lib/api"
import { useEffect, useMemo, useState } from "react"
import type { Order as OrderType, Payment as PaymentType } from "@/server/mockDb"
import { CheckCircle, AlertTriangle } from "lucide-react"

export default function OrdersPage() {
  const [data, setData] = useState<OrderType[]>([])
  const [payments, setPayments] = useState<PaymentType[]>([])
  const [selected, setSelected] = useState<OrderType | null>(null)
  const [query, setQuery] = useState("")
  const [status, setStatus] = useState("")

  useEffect(() => {
    apiGet<OrderType[]>("/api/orders").then(setData)
    apiGet<PaymentType[]>("/api/payments").then(setPayments)
  }, [])

  const filtered = useMemo(() => {
    return data.filter(o => {
      const okQuery = query ? [o.id, o.merchantId].join(" ").toLowerCase().includes(query.toLowerCase()) : true
      const okStatus = status ? o.status === status : true
      return okQuery && okStatus
    })
  }, [data, query, status])

  return (
    <RoleGuard allowed={["agent", "manager", "admin"]}>
      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Search & Filters">
          <SearchFilterBar
            query={query}
            onQueryChange={setQuery}
            status={status}
            onStatusChange={setStatus}
            statuses={["created", "packed", "shipped", "delivered", "cancelled"]}
          />
        </Card>
        <Card title="Summary">
          <div className="text-sm text-gray-600">Orders loaded: {data.length}</div>
        </Card>
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <DataTable<OrderType>
          columns={[
            { key: "id", header: "Order" },
            { key: "merchantId", header: "Merchant" },
            { key: "status", header: "Status", render: (o) => <Badge text={o.status} variant={o.status === "delivered" ? "success" : o.status === "cancelled" ? "error" : "default"} /> },
            { key: "createdAt", header: "Indicators", render: (o) => {
              const pay = payments.find(p => p.orderId === o.id)
              const okDelivery = o.status === "delivered"
              const hasIssue = pay?.status === "discrepancy"
              return (
                <div className="flex items-center gap-2">
                  {okDelivery ? <CheckCircle className="h-4 w-4 text-green-600" /> : null}
                  {hasIssue ? <AlertTriangle className="h-4 w-4 text-red-600" /> : null}
                </div>
              )
            } },
          ]}
          data={filtered}
          onRowClick={(row) => setSelected(row)}
        />
        <Card title="Timeline">
          {selected ? <Timeline items={selected.timeline} /> : <div className="text-sm text-gray-600">Select an order</div>}
        </Card>
      </div>
    </RoleGuard>
  )
}
