"use client"
import Card from "@/components/Card"
import DataTable from "@/components/DataTable"
import Badge from "@/components/Badge"
import Alert from "@/components/Alert"
import { RoleGuard } from "@/lib/auth"
import { apiGet } from "@/lib/api"
import { useEffect, useMemo, useState } from "react"
import type { Payment as PaymentType } from "@/server/mockDb"

export default function PaymentsPage() {
  const [data, setData] = useState<PaymentType[]>([])
  useEffect(() => { apiGet<PaymentType[]>("/api/payments").then(setData) }, [])

  const totals = useMemo(() => ({
    total: data.reduce((s, d) => s + d.amount, 0),
    paid: data.filter(d => d.status === "paid").reduce((s, d) => s + d.amount, 0)
  }), [data])

  function resolve(id: string) {
    setData(prev => prev.map(p => p.id === id ? { ...p, status: "paid" } : p))
  }

  return (
    <RoleGuard allowed={["manager", "admin"]}>
      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Payouts">
          <div className="flex items-center gap-4 text-sm">
            <div>
              <div className="text-gray-600">Total</div>
              <div className="font-semibold">${totals.total.toFixed(2)}</div>
            </div>
            <div>
              <div className="text-gray-600">Paid</div>
              <div className="font-semibold">${totals.paid.toFixed(2)}</div>
            </div>
          </div>
        </Card>
        <Card title="Pending">
          <div className="text-sm">{data.filter(d => d.status === "pending").length} pending settlements</div>
        </Card>
        <Card title="Discrepancies">
          <div className="text-sm">{data.filter(d => d.status === "discrepancy").length} flags</div>
        </Card>
      </div>
      <div className="mt-4 space-y-3">
        {data.filter(d => d.status === "discrepancy").map(d => (
          <Alert key={d.id} title={`Discrepancy on ${d.id}`} description={`Order ${d.orderId} has mismatched settlement`} variant="error" />
        ))}
        <DataTable<PaymentType>
          columns={[
            { key: "id", header: "Payment" },
            { key: "orderId", header: "Order" },
            { key: "amount", header: "Amount" },
            { key: "status", header: "Status", render: (p) => <Badge text={p.status} variant={p.status === "paid" ? "success" : p.status === "discrepancy" ? "error" : "default"} /> },
            { key: "id", header: "Action", render: (p) => p.status === "discrepancy" ? <button className="rounded bg-brand-500 px-3 py-1 text-xs text-white" onClick={() => resolve(p.id)}>Resolve</button> : null }
          ]}
          data={data}
        />
      </div>
    </RoleGuard>
  )
}
