"use client"
import Card from "@/components/Card"
import { useAuth } from "@/lib/auth"

export default function DashboardPage() {
  const { role } = useAuth()
  return (
    <div className="grid gap-4 md:grid-cols-3">
      <Card title="Welcome">
        <div className="text-sm text-gray-700">Role: {role ?? "none"}</div>
      </Card>
      <Card title="Merchants">
        <div className="text-2xl font-semibold">3</div>
        <div className="text-xs text-gray-500">Active merchants</div>
      </Card>
      <Card title="Orders">
        <div className="text-2xl font-semibold">2</div>
        <div className="text-xs text-gray-500">Recent orders</div>
      </Card>
    </div>
  )
}
