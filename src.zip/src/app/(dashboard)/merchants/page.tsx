"use client"
import Card from "@/components/Card"
import DataTable from "@/components/DataTable"
import Badge from "@/components/Badge"
import Modal from "@/components/Modal"
import UploadBox from "@/components/UploadBox"
import { Stepper } from "@/components/Stepper"
import { RoleGuard } from "@/lib/auth"
import { apiGet, apiPost } from "@/lib/api"
import { useEffect, useState } from "react"
import type { Merchant as MerchantType } from "@/server/mockDb"

export default function MerchantsPage() {
  const [data, setData] = useState<MerchantType[]>([])
  const [open, setOpen] = useState(false)
  const [name, setName] = useState("")
  const [status, setStatus] = useState<MerchantType["status"]>("draft")
  const [docs, setDocs] = useState<{ name: string; url?: string }[]>([])
  const [step, setStep] = useState(0)

  useEffect(() => {
    apiGet<MerchantType[]>("/api/merchants").then(setData)
  }, [])

  function submit() {
    apiPost("/api/merchants", { name, status, documents: docs }).then(() => {
      setOpen(false)
      setName("")
      setStatus("draft")
      setDocs([])
      setStep(0)
    })
  }

  return (
    <RoleGuard allowed={["agent", "manager", "admin"]}>
      <div className="grid gap-4 md:grid-cols-3">
        <Card title="Onboarding">
          <button className="rounded bg-brand-500 px-3 py-2 text-sm text-white" onClick={() => setOpen(true)}>New merchant</button>
        </Card>
        <Card title="Status">
          <div className="space-x-2">
            <Badge text="Draft" />
            <Badge text="Submitted" variant="warn" />
            <Badge text="Approved" variant="success" />
            <Badge text="Rejected" variant="error" />
          </div>
        </Card>
        <Card title="Approvals">
          <div className="text-sm">{data.filter(m => m.status === "submitted").length} pending</div>
        </Card>
      </div>
      <div className="mt-4">
        <DataTable<MerchantType>
          columns={[
            { key: "id", header: "ID" },
            { key: "name", header: "Name" },
            { key: "status", header: "Status", render: (m) => <Badge text={m.status} variant={m.status === "approved" ? "success" : m.status === "submitted" ? "warn" : m.status === "rejected" ? "error" : "default"} /> }
          ]}
          data={data}
        />
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="New merchant">
        <div className="space-y-4">
          <Stepper steps={["Basic", "Documents", "Review"]} current={step} />
          {step === 0 && (
            <div className="space-y-3">
              <input value={name} onChange={e => setName(e.target.value)} placeholder="Business name" className="w-full rounded border px-3 py-2" />
              <select value={status} onChange={e => setStatus(e.target.value as MerchantType["status"])} className="w-full rounded border px-3 py-2">
                <option value="draft">Draft</option>
                <option value="submitted">Submitted</option>
              </select>
            </div>
          )}
          {step === 1 && (
            <UploadBox files={docs} onChange={setDocs} />
          )}
          {step === 2 && (
            <div className="space-y-2 text-sm">
              <div className="font-medium">Review</div>
              <div>Name: {name || "-"}</div>
              <div>Status: {status}</div>
              <div>Docs: {docs.length}</div>
            </div>
          )}
          <div className="flex justify-between">
            <button className="rounded px-3 py-2" onClick={() => setStep(Math.max(0, step - 1))}>Back</button>
            {step < 2 ? (
              <button className="rounded bg-gray-800 px-3 py-2 text-white" onClick={() => setStep(step + 1)}>Next</button>
            ) : (
              <button className="rounded bg-brand-500 px-3 py-2 text-white" onClick={submit}>Submit</button>
            )}
          </div>
        </div>
      </Modal>
    </RoleGuard>
  )
}
