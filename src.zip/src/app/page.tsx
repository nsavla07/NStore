import Link from "next/link"

export default function HomePage() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <Link href="/login" className="rounded bg-gray-800 px-4 py-2 text-white">Go to login</Link>
    </div>
  )
}
