"use client"
import { useAuth, Role } from "@/lib/auth"
import Link from "next/link"

const roles: Role[] = ["agent", "manager", "admin"]

export default function LoginPage() {
  const { role, setRole } = useAuth()
  return (
    <div className="w-full max-w-sm rounded border bg-white p-6">
      <div className="mb-4 text-center text-lg font-semibold">Sign in</div>
      <label className="mb-2 block text-sm">Select role</label>
      <select value={role ?? ""} onChange={e => setRole(e.target.value as Role)} className="mb-4 w-full rounded border px-3 py-2">
        <option value="">Choose</option>
        {roles.map(r => (
          <option key={r} value={r}>{r}</option>
        ))}
      </select>
      <Link href="/dashboard" className="block w-full rounded bg-gray-800 px-4 py-2 text-center text-white">Continue</Link>
    </div>
  )
}
