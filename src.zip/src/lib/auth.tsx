"use client"
import { createContext, useContext, useEffect, useMemo, useState } from "react"

export type Role = "agent" | "manager" | "admin"

type AuthContextValue = {
  role: Role | null
  setRole: (r: Role | null) => void
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [role, setRole] = useState<Role | null>(null)

  useEffect(() => {
    const saved = typeof window !== "undefined" ? window.localStorage.getItem("role") : null
    if (saved) setRole(saved as Role)
  }, [])

  const value = useMemo(() => ({ role, setRole: (r: Role | null) => {
    setRole(r)
    if (typeof window !== "undefined") {
      if (r) window.localStorage.setItem("role", r)
      else window.localStorage.removeItem("role")
    }
  } }), [role])

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error("useAuth must be used within AuthProvider")
  return ctx
}

export function RoleGuard({ allowed, children }: { allowed: Role[]; children: React.ReactNode }) {
  const { role } = useAuth()
  if (!role) return <div className="p-6">Sign in required</div>
  if (!allowed.includes(role)) return <div className="p-6">Not authorized</div>
  return <>{children}</>
}
