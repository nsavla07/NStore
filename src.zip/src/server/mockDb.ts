export type Merchant = {
  id: string
  name: string
  status: "draft" | "submitted" | "approved" | "rejected"
  documents: { name: string; url: string }[]
}

export type Order = {
  id: string
  merchantId: string
  status: "created" | "packed" | "shipped" | "delivered" | "cancelled"
  createdAt: string
  timeline: { label: string; at: string }[]
}

export type Payment = {
  id: string
  orderId: string
  amount: number
  status: "pending" | "paid" | "discrepancy"
}

export type Ticket = {
  id: string
  title: string
  status: "open" | "in_progress" | "resolved"
  priority: "low" | "medium" | "high"
  assigneeRole: "agent" | "manager" | "admin" | null
  comments: { by: string; text: string; at: string }[]
}

export const merchants: Merchant[] = [
  { id: "m-1001", name: "Acme Retail", status: "approved", documents: [{ name: "GST", url: "/docs/acme-gst.pdf" }] },
  { id: "m-1002", name: "Blue Ocean", status: "submitted", documents: [] },
  { id: "m-1003", name: "Nova Fashions", status: "draft", documents: [] }
]

export const orders: Order[] = [
  {
    id: "o-5001",
    merchantId: "m-1001",
    status: "shipped",
    createdAt: new Date().toISOString(),
    timeline: [
      { label: "Created", at: new Date(Date.now() - 86_400_000 * 3).toISOString() },
      { label: "Packed", at: new Date(Date.now() - 86_400_000 * 2).toISOString() },
      { label: "Shipped", at: new Date(Date.now() - 86_400_000).toISOString() }
    ]
  },
  {
    id: "o-5002",
    merchantId: "m-1002",
    status: "delivered",
    createdAt: new Date().toISOString(),
    timeline: [
      { label: "Created", at: new Date(Date.now() - 86_400_000 * 5).toISOString() },
      { label: "Packed", at: new Date(Date.now() - 86_400_000 * 4).toISOString() },
      { label: "Shipped", at: new Date(Date.now() - 86_400_000 * 3).toISOString() },
      { label: "Delivered", at: new Date(Date.now() - 86_400_000).toISOString() }
    ]
  }
]

export const payments: Payment[] = [
  { id: "p-9001", orderId: "o-5001", amount: 129.99, status: "pending" },
  { id: "p-9002", orderId: "o-5002", amount: 79.5, status: "discrepancy" }
]

export const tickets: Ticket[] = [
  {
    id: "t-7001",
    title: "Address update",
    status: "open",
    priority: "medium",
    assigneeRole: null,
    comments: [{ by: "agent", text: "Customer requested change", at: new Date().toISOString() }]
  },
  {
    id: "t-7002",
    title: "Payment mismatch",
    status: "in_progress",
    priority: "high",
    assigneeRole: "manager",
    comments: [{ by: "manager", text: "Investigating discrepancy", at: new Date().toISOString() }]
  }
]
