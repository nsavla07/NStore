"use client"
import { useAuth, Role } from "@/lib/auth"
import { useRouter } from "next/navigation"

const roles: Role[] = ["agent", "manager", "admin"]

export default function Topbar() {
  const { role, setRole } = useAuth()
  const router = useRouter()
  return (
    <header className="flex h-14 items-center justify-between border-b bg-white px-4">
      <div className="text-sm text-gray-600">Internal Operations Portal</div>
      <div className="flex items-center gap-2">
        <select
          value={role ?? ""}
          onChange={e => setRole(e.target.value ? (e.target.value as Role) : null)}
          className="rounded border px-2 py-1 text-sm"
        >
          <option value="">Select role</option>
          {roles.map(r => (
            <option key={r} value={r}>{r}</option>
          ))}
        </select>
        <button className="rounded bg-gray-800 px-3 py-1 text-sm text-white" onClick={() => router.push("/login")}>Sign In</button>
      </div>
    </header>
  )
}
