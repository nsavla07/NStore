type Column<T> = { key: keyof T; header: string; render?: (row: T) => React.ReactNode }

export default function DataTable<T extends { id: string }>({ columns, data, onRowClick }: { columns: Column<T>[]; data: T[]; onRowClick?: (row: T) => void }) {
  return (
    <div className="overflow-hidden rounded border bg-white">
      <table className="w-full text-left text-sm">
        <thead className="bg-gray-50 text-gray-600">
          <tr>
            {columns.map(c => (
              <th key={String(c.key)} className="px-3 py-2">{c.header}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map(row => (
            <tr key={row.id} className="border-t hover:bg-gray-50 cursor-pointer" onClick={() => onRowClick?.(row)}>
              {columns.map(c => (
                <td key={String(c.key)} className="px-3 py-2 text-gray-800">
                  {c.render ? c.render(row) : String(row[c.key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
