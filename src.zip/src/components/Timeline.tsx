export function Timeline({ items }: { items: { label: string; at: string }[] }) {
  return (
    <ol className="space-y-3">
      {items.map((i, idx) => (
        <li key={idx} className="flex items-center gap-3">
          <div className="h-2 w-2 rounded-full bg-brand-500" />
          <div className="text-sm">
            <div className="font-medium">{i.label}</div>
            <div className="text-gray-500">{new Date(i.at).toLocaleString()}</div>
          </div>
        </li>
      ))}
    </ol>
  )
}
