import clsx from "clsx"

export function Stepper({ steps, current }: { steps: string[]; current: number }) {
  return (
    <div className="flex items-center gap-3">
      {steps.map((s, i) => (
        <div key={s} className="flex items-center gap-3">
          <div className={clsx("rounded-full px-2.5 py-1 text-xs", i === current ? "bg-brand-500 text-white" : "bg-gray-100 text-gray-700")}>{i + 1}</div>
          <div className={clsx("text-sm", i === current ? "font-medium text-gray-900" : "text-gray-600")}>{s}</div>
          {i < steps.length - 1 ? <div className="h-px w-8 bg-gray-200" /> : null}
        </div>
      ))}
    </div>
  )
}
