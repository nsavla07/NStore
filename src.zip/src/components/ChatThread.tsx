"use client"
import React from "react"

type Msg = { by: string; text: string; at: string }

export default function ChatThread({ messages, onSend }: { messages: Msg[]; onSend: (text: string) => void }) {
  const [text, setText] = React.useState("")
  return (
    <div className="flex h-full flex-col">
      <div className="flex-1 space-y-3 overflow-y-auto rounded border bg-white p-3">
        {messages.map((m, i) => (
          <div key={i} className="max-w-md rounded bg-gray-50 p-2">
            <div className="text-xs text-gray-500">{m.by} • {new Date(m.at).toLocaleString()}</div>
            <div className="text-sm text-gray-800">{m.text}</div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex items-center gap-2">
        <input value={text} onChange={e => setText(e.target.value)} placeholder="Type a message" className="flex-1 rounded border px-3 py-2 text-sm" />
        <button className="rounded bg-brand-500 px-3 py-2 text-sm text-white" onClick={() => { if (text.trim()) { onSend(text.trim()); setText("") } }}>Send</button>
      </div>
    </div>
  )
}
