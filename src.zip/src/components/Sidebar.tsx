"use client"
import Link from "next/link"
import { useAuth } from "@/lib/auth"
import clsx from "clsx"
import { usePathname } from "next/navigation"
import { LayoutDashboard, Users, Package, Wallet, LifeBuoy } from "lucide-react"

const items = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ["agent", "manager", "admin"] },
  { href: "/merchants", label: "Merchant Onboarding", icon: Users, roles: ["agent", "manager", "admin"] },
  { href: "/orders", label: "Order Tracking", icon: Package, roles: ["agent", "manager", "admin"] },
  { href: "/payments", label: "Payment Reconciliation", icon: Wallet, roles: ["manager", "admin"] },
  { href: "/tickets", label: "Support Tickets", icon: LifeBuoy, roles: ["agent", "manager", "admin"] }
]

export default function Sidebar() {
  const { role } = useAuth()
  const pathname = usePathname()
  return (
    <aside className="w-64 border-r bg-white">
      <div className="p-4 text-lg font-semibold">NStore Ops</div>
      <nav className="space-y-1 p-2">
        {items.filter(i => role ? i.roles.includes(role) : true).map(i => {
          const Icon = i.icon
          const active = pathname === i.href
          return (
            <Link key={i.href} href={i.href} className={clsx("flex items-center gap-2 rounded px-3 py-2 text-sm", active ? "bg-brand-50 text-brand-700" : "hover:bg-gray-50")}> 
              <Icon className="h-4 w-4" />
              <span>{i.label}</span>
            </Link>
          )
        })}
      </nav>
    </aside>
  )
}
