import clsx from "clsx"

export default function Badge({ text, variant }: { text: string; variant?: "default" | "success" | "warn" | "error" }) {
  const color = variant === "success" ? "bg-green-100 text-green-700" : variant === "warn" ? "bg-yellow-100 text-yellow-700" : variant === "error" ? "bg-red-100 text-red-700" : "bg-gray-100 text-gray-700"
  return <span className={clsx("inline-flex rounded px-2 py-0.5 text-xs", color)}>{text}</span>
}
