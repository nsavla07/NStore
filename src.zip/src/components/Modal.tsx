"use client"
import { Dialog } from "@headlessui/react"

export default function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title?: string; children: React.ReactNode }) {
  return (
    <Dialog open={open} onClose={onClose} className="relative z-50">
      <div className="fixed inset-0 bg-black/20" />
      <div className="fixed inset-0 flex items-center justify-center p-4">
        <Dialog.Panel className="w-full max-w-lg rounded bg-white p-4">
          {title ? <Dialog.Title className="mb-2 text-sm font-medium">{title}</Dialog.Title> : null}
          {children}
        </Dialog.Panel>
      </div>
    </Dialog>
  )
}
