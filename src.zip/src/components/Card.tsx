export default function Card({ title, children, className }: { title?: string; children: React.ReactNode; className?: string }) {
  return (
    <div className={`rounded border bg-white p-4 ${className ?? ""}`}>
      {title ? <div className="mb-2 text-sm font-medium text-gray-700">{title}</div> : null}
      {children}
    </div>
  )
}
