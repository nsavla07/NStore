"use client"

export default function UploadBox({ files, onChange }: { files: { name: string; url?: string }[]; onChange: (f: { name: string; url?: string }[]) => void }) {
  function handleInput(e: React.ChangeEvent<HTMLInputElement>) {
    const sel = Array.from(e.target.files ?? []).map(f => ({ name: f.name }))
    onChange([...(files ?? []), ...sel])
  }
  return (
    <div className="rounded border bg-white p-3">
      <div className="mb-2 text-sm">Documents</div>
      <input type="file" multiple onChange={handleInput} className="mb-3" />
      <ul className="space-y-1 text-sm">
        {files.map((f, i) => (
          <li key={i} className="flex items-center justify-between">
            <span className="text-gray-800">{f.name}</span>
            <button className="text-red-600" onClick={() => onChange(files.filter((_, idx) => idx !== i))}>Remove</button>
          </li>
        ))}
      </ul>
    </div>
  )
}
