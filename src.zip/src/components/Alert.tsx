import clsx from "clsx"

export default function Alert({ title, description, variant = "info" }: { title: string; description?: string; variant?: "info" | "warn" | "error" | "success" }) {
  const colors = variant === "success" ? "bg-green-50 text-green-800 border-green-200" : variant === "warn" ? "bg-yellow-50 text-yellow-800 border-yellow-200" : variant === "error" ? "bg-red-50 text-red-800 border-red-200" : "bg-gray-50 text-gray-800 border-gray-200"
  return (
    <div className={clsx("rounded border p-3", colors)}>
      <div className="text-sm font-medium">{title}</div>
      {description ? <div className="text-xs">{description}</div> : null}
    </div>
  )
}
