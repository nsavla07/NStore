"use client"

export default function SearchFilterBar({ query, onQueryChange, status, onStatusChange, statuses }: { query: string; onQueryChange: (q: string) => void; status: string; onStatusChange: (s: string) => void; statuses: string[] }) {
  return (
    <div className="flex items-center gap-2">
      <input value={query} onChange={e => onQueryChange(e.target.value)} placeholder="Search orders" className="w-full max-w-xs rounded border px-3 py-2 text-sm" />
      <select value={status} onChange={e => onStatusChange(e.target.value)} className="rounded border px-2 py-2 text-sm">
        <option value="">All statuses</option>
        {statuses.map(s => <option key={s} value={s}>{s}</option>)}
      </select>
    </div>
  )
}
